<?php
$config['system_site_short_name']='bas';
$config['system_max_actions']=7;

$config['system_status_active']='Active';
$config['system_status_inactive']='In-Active';
$config['system_status_delete']='Deleted';

/*$config['start_year']='2015';
$config['booking_status_preliminary']='Preliminary';
$config['booking_status_permanent']='Permanent';
$config['booking_status_other']='Other';

$config['payment_method']['cheque']='Cheque';
$config['payment_method']['pay_order']='Pay Order';
$config['payment_method']['bank_guarantee']='Bank Guarantee';
$config['payment_method']['online_payment']='Online Payment';
$config['payment_method']['dd']='DD';
$config['payment_method']['cash']='Cash';
$config['payment_method']['mobile_banking']='Mobile Banking';
$config['payment_method']['others']='Others';

$config['consignment_status']['ready']='Ready';
$config['consignment_status']['complete']='Completed';
$config['consignment_status']['allocation']='Allocation';*/




