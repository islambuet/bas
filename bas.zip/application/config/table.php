<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//those tables from login site
$config['table_setup_user'] = 'setup_user';
$config['table_setup_user_info'] = 'setup_user_info';
$config['table_setup_users_other_sites'] = 'setup_users_other_sites';
$config['table_system_other_sites'] = 'system_other_sites';
$config['table_other_sites_visit'] = 'other_sites_visit';
$config['table_setup_designation'] = 'setup_designation';


//pms system setup tables
$config['table_system_assigned_group'] = 'bas_system_assigned_group';
$config['table_system_user_group'] = 'bas_system_user_group';
$config['table_system_task'] = 'bas_system_task';
$config['table_system_user_group_role'] = 'bas_system_user_group_role';
$config['table_history'] = 'bas_history';
$config['table_history_hack'] = 'bas_history_hack';
//$config['table_system_assigned_area'] = 'bms_system_assigned_area';
$config['table_system_site_offline'] = 'bas_system_site_offline';

//pms site tables